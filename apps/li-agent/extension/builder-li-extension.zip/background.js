// Service worker — all cross-origin fetch calls live here to avoid CORS.
// The panel sends messages here; we call the outreach app and reply.

const APP_URL = "https://xdr-hub.netlify.app/li-agent";
const POLL_INITIAL_MS = 3000;  // first poll after 3s
const POLL_MAX_MS = 15000;     // cap each interval at 15s
const POLL_TIMEOUT_MS = 60000; // give up after 60s

async function getSettings() {
  const result = await chrome.storage.local.get(["apiToken"]);
  return {
    appUrl: APP_URL,
    apiToken: result.apiToken || "",
  };
}

// This poll loop's setTimeout waits (up to POLL_TIMEOUT_MS) don't themselves
// reset the service worker's 30s idle timer, but that's not a real risk
// here: it only ever runs from the DRAFT_REQUEST onMessage handler below,
// which returns `true` and leaves sendResponse uncalled until this promise
// settles -- Chrome treats that outstanding response as an active task and
// keeps the worker alive for it, the same mechanism the LOAD_POST_ENGAGERS
// port relies on further down. Don't reach for chrome.alarms here; alarms
// have a 1-minute minimum granularity and can't drive this reasonably-fast
// exponential backoff anyway.
async function captureThenPoll(profileData) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) throw new Error("App URL not set. Open Options and paste your outreach app URL.");

  // POST to capture-profile — returns status "drafted" directly with the note
  const captureRes = await fetch(
    `${appUrl}/_agent-native/actions/capture-profile`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...profileData, ...(apiToken ? { apiToken } : {}) }),
    },
  );
  if (!captureRes.ok) {
    const text = await captureRes.text();
    throw new Error(`capture-profile failed (${captureRes.status}): ${text}`);
  }

  const result = await captureRes.json();

  // If draft is already in the response (inline drafting), return immediately
  if (result.status === "drafted" && result.draftNote !== undefined) {
    return result;
  }

  // Fallback: poll get-draft if status is still "captured" (agent-async path)
  const deadline = Date.now() + POLL_TIMEOUT_MS;
  const profileUrl = profileData.profileUrl;
  const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";

  let pollInterval = POLL_INITIAL_MS;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, pollInterval));
    pollInterval = Math.min(pollInterval * 2, POLL_MAX_MS);

    const draftRes = await fetch(
      `${appUrl}/_agent-native/actions/get-draft?profileUrl=${encodeURIComponent(profileUrl)}${tokenParam}`,
    );
    if (!draftRes.ok) continue;

    const draft = await draftRes.json();
    if (draft.status === "drafted") return draft;
  }

  throw new Error("Timed out waiting for the draft.");
}

async function checkAlreadyContacted(profileUrl) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) return { contacted: false };
  try {
    const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
    const res = await fetch(
      `${appUrl}/_agent-native/actions/check-already-contacted?profileUrl=${encodeURIComponent(profileUrl)}${tokenParam}`,
    );
    if (!res.ok) return { contacted: false };
    return await res.json();
  } catch {
    return { contacted: false };
  }
}

async function markSent(profileUrl) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) throw new Error("App URL not set.");
  const res = await fetch(`${appUrl}/_agent-native/actions/mark-sent`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ profileUrl, ...(apiToken ? { apiToken } : {}) }),
  });
  if (!res.ok) throw new Error(`mark-sent failed (${res.status})`);
  return await res.json();
}

async function getExistingDraft(profileUrl) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) return null;
  try {
    const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
    const res = await fetch(
      `${appUrl}/_agent-native/actions/get-draft?profileUrl=${encodeURIComponent(profileUrl)}${tokenParam}`,
    );
    if (!res.ok) return null;
    const json = await res.json();
    return json.ok && json.status === "drafted" ? json : null;
  } catch {
    return null;
  }
}

async function submitFeedback({ sentiment, message, draftNote }) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) return { ok: false, error: "App URL not configured" };
  try {
    const body = {
      ...(apiToken ? { apiToken } : {}),
      ...(sentiment ? { sentiment } : {}),
      message: message || "",
      ...(draftNote ? { draftNote } : {}),
    };
    const res = await fetch(`${appUrl}/_agent-native/actions/submit-feedback`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error("[BLI] submit-feedback error", res.status, text.slice(0, 300));
      return { ok: false, error: `${res.status}: ${text.slice(0, 100)}` };
    }
    return await res.json();
  } catch (err) {
    console.error("[BLI] submit-feedback fetch error", err);
    return { ok: false, error: String(err) };
  }
}

async function resolveConnectButton(profileName, candidates) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) throw new Error("App URL not configured.");
  const res = await fetch(`${appUrl}/_agent-native/actions/resolve-connect-button`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ profileName, candidates, ...(apiToken ? { apiToken } : {}) }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`resolve-connect-button failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json();
}

// Reflects the daily send limit on the extension icon itself -- the one
// genuinely actionable at-a-glance state this extension has (per
// feedback-badge-status: keep badge text under 4 characters, only show it
// when there's something to act on). Cleared entirely below 80% of the
// limit so the icon stays quiet during normal use.
function updateBadgeFromDailyStats(stats) {
  if (!stats || stats.limit == null) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }
  const { capturedToday = 0, limit } = stats;
  if (capturedToday >= limit) {
    chrome.action.setBadgeBackgroundColor({ color: "#c0392b" });
    chrome.action.setBadgeText({ text: "MAX" });
  } else if (capturedToday >= limit * 0.8) {
    const remaining = Math.max(0, limit - capturedToday);
    chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
    chrome.action.setBadgeText({ text: String(remaining) });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

async function getDailyStats() {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) return null;
  try {
    const tokenParam = apiToken ? `?apiToken=${encodeURIComponent(apiToken)}` : "";
    const res = await fetch(
      `${appUrl}/_agent-native/actions/get-daily-stats${tokenParam}`,
    );
    if (!res.ok) return null;
    const stats = await res.json();
    updateBadgeFromDailyStats(stats);
    return stats;
  } catch {
    return null;
  }
}

async function checkHubspot(profileUrl, name, company) {
  const { appUrl, apiToken } = await getSettings();
  if (!appUrl) return { found: false };
  try {
    const params = new URLSearchParams({ profileUrl });
    if (name) params.set("name", name);
    if (company) params.set("company", company);
    if (apiToken) params.set("apiToken", apiToken);
    const url = `${appUrl}/_agent-native/actions/check-hubspot-contact?${params.toString()}`;
    console.log("[BLI] HubSpot lookup →", { profileUrl, name, company });
    const res = await fetch(url);
    if (!res.ok) {
      console.warn("[BLI] HubSpot lookup failed", res.status, await res.text().catch(() => ""));
      return { found: false };
    }
    const json = await res.json();
    console.log("[BLI] HubSpot result ←", json);
    return json;
  } catch (err) {
    console.error("[BLI] HubSpot lookup error", err);
    return { found: false };
  }
}

async function listCanvases(apiToken) {
  const { appUrl } = await getSettings();
  if (!appUrl) return { canvases: [] };
  try {
    const tokenParam = apiToken ? `?apiToken=${encodeURIComponent(apiToken)}` : "";
    const res = await fetch(`${appUrl}/_agent-native/actions/list-canvases${tokenParam}`);
    if (!res.ok) return { canvases: [] };
    const json = await res.json();
    // Extension only shows user-owned canvases (isSystem === 0)
    return { canvases: (json.canvases ?? []).filter((c) => c.isSystem === 0) };
  } catch {
    return { canvases: [] };
  }
}

async function ingestPostEngager(engager, apiToken) {
  const { appUrl } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/ingest-post-engager`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      postUrl: engager.postUrl,
      postTitle: engager.postTitle ?? null,
      engagerName: engager.name,
      engagerCompany: engager.company ?? null,
      engagerProfileUrl: engager.profileUrl,
      commentText: engager.commentText ?? null,
      ...(apiToken ? { apiToken } : {}),
    }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`ingest-post-engager failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { ok, id, status }
}

async function enrichPostEngager(id, profileData, apiToken) {
  const { appUrl } = await getSettings();
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 45000);
  try {
    const res = await fetch(`${appUrl}/_agent-native/actions/enrich-post-engager`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...profileData, ...(apiToken ? { apiToken } : {}) }),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`enrich-post-engager failed (${res.status}): ${text.slice(0, 200)}`);
    }
    return await res.json();
  } catch (err) {
    clearTimeout(timeoutId);
    throw err;
  }
}

async function getPostEngager(id, apiToken) {
  const { appUrl } = await getSettings();
  const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
  const res = await fetch(`${appUrl}/_agent-native/actions/get-post-engager?id=${encodeURIComponent(id)}${tokenParam}`);
  if (!res.ok) return null;
  return await res.json();
}

// Powers content.js's "already in your list" chip -- given the batch of
// salesNavLeadUrls visible on the current page, returns which ones this
// owner already captured into any lead list. Best-effort: a failed check
// just means no chip shows for that batch, never surfaced as an error to
// the xDR (this is a passive visual hint, not a blocking action).
async function checkSalesNavLeadsCaptured(salesNavLeadUrls) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/check-sales-nav-leads-captured`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ salesNavLeadUrls, ...(apiToken ? { apiToken } : {}) }),
  });
  if (!res.ok) return { capturedUrls: [] };
  return await res.json(); // { capturedUrls: string[] }
}

async function importSalesNavList({ listName, listDescription, listUrl, existingListId, leads }) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/import-sales-nav-list`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      listName,
      listDescription: listDescription ?? null,
      listUrl: listUrl ?? null,
      existingListId: existingListId ?? null,
      leads,
      ...(apiToken ? { apiToken } : {}),
    }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`import-sales-nav-list failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { listId, totalCount, truncated? }
}

async function getContact({ profileUrl, wantEmail, wantPhone, override }) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/extension-get-contact`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      profileUrl,
      wantEmail: !!wantEmail,
      wantPhone: !!wantPhone,
      // Echoed cost. The server rejects a phone request without it, so a
      // stale extension cannot spend 8 credits by accident.
      confirmCredits: wantPhone ? 8 : null,
      override: !!override,
      apiToken: apiToken || null,
    }),
  });
  const json = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(json?.error || `extension-get-contact failed (${res.status})`);
  }
  return json;
}

async function listLeadLists() {
  const { appUrl, apiToken } = await getSettings();
  const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
  const res = await fetch(`${appUrl}/_agent-native/actions/list-lead-lists-for-extension?x=1${tokenParam}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`list-lead-lists-for-extension failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { lists: [{ id, name, totalCount }] }
}

async function checkLeadsInLists(salesNavLeadUrls) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/check-leads-in-lists`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ salesNavLeadUrls, apiToken: apiToken || null }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`check-leads-in-lists failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { inLists: { [url]: { listId, listName, addedAt } }, checked }
}

async function getLeadListItems(listId) {
  const { appUrl, apiToken } = await getSettings();
  const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
  const res = await fetch(`${appUrl}/_agent-native/actions/get-lead-list-items-for-extension?listId=${encodeURIComponent(listId)}${tokenParam}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`get-lead-list-items-for-extension failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { list, items: [...] }
}

async function summarizeLeadList(listId) {
  const { appUrl, apiToken } = await getSettings();
  const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
  const res = await fetch(`${appUrl}/_agent-native/actions/summarize-lead-list-for-extension?listId=${encodeURIComponent(listId)}${tokenParam}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`summarize-lead-list-for-extension failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { summary: string | null }
}

// ── ICP personas ────────────────────────────────────────────────────────────
// Lets the rep attach ICP documents to a persona without leaving LinkedIn.
// All three actions are admin-gated server-side (requireAdminFromSessionOrToken)
// -- the token only identifies who is calling, it doesn't grant the right to
// edit the team's ICP. A non-admin gets an error back and the panel says so.

async function listIcpPersonas() {
  const { appUrl, apiToken } = await getSettings();
  const tokenParam = apiToken ? `&apiToken=${encodeURIComponent(apiToken)}` : "";
  const res = await fetch(`${appUrl}/_agent-native/actions/list-icp-personas?x=1${tokenParam}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`list-icp-personas failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { personas: [{ id, name, color, documents, docCount, wordCount, isActive }] }
}

async function addPersonaDocuments(personaId, documents) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/add-persona-documents`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ personaId, documents, ...(apiToken ? { apiToken } : {}) }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`add-persona-documents failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { ok, docCount, wordCount } or { ok: false, error }
}

async function deletePersonaDocument(id) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/delete-persona-document`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, ...(apiToken ? { apiToken } : {}) }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`delete-persona-document failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { ok, docCount, wordCount } or { ok: false, error }
}

async function generateSalesNavSearch(prompt) {
  const { appUrl, apiToken } = await getSettings();
  const res = await fetch(`${appUrl}/_agent-native/actions/generate-sales-nav-search`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt, ...(apiToken ? { apiToken } : {}) }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`generate-sales-nav-search failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json(); // { searchUrl, summary, matchedPersonaName } or { error }
}

// Scrapes the LinkedIn profile at profileUrl in a background tab, returns the
// profile data. Opens a non-active tab, waits for load, injects the content
// script, reads the profile, closes the tab.
async function scrapeProfileInBackground(profileUrl) {
  return new Promise((resolve) => {
    chrome.tabs.create({ url: profileUrl, active: false }, (tab) => {
      const tabId = tab.id;
      const timeout = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.tabs.remove(tabId).catch(() => {});
        resolve(null);
      }, 20000); // 20s hard timeout per profile

      let scraped = false;
      function doScrape() {
        if (scraped) return;
        scraped = true;
        chrome.tabs.onUpdated.removeListener(onUpdated);
        clearTimeout(timeout);
        chrome.scripting.executeScript(
          { target: { tabId }, files: ["content.js"] },
          () => {
            chrome.tabs.sendMessage(tabId, { type: "SCRAPE_PROFILE" }, (result) => {
              chrome.tabs.remove(tabId).catch(() => {});
              resolve(result?.ok ? result.data : null);
            });
          }
        );
      }

      function onUpdated(updatedTabId, changeInfo) {
        if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
        doScrape();
      }

      chrome.tabs.onUpdated.addListener(onUpdated);
      // Race guard: if the tab already reached "complete" before the listener
      // was registered (e.g., served from cache), scrape immediately.
      chrome.tabs.get(tabId, (tab) => {
        if (tab?.status === "complete") doScrape();
      });
    });
  });
}

// Loads an array of selected engager objects: ingests all at once (to create
// DB rows and return ids quickly), then enriches each sequentially (to avoid
// LinkedIn rate-limiting on background tab opens).
async function loadPostEngagers(engagers, sendProgress) {
  const { apiToken } = await chrome.storage.local.get(["apiToken"]);
  const token = apiToken || "";

  // Phase 1: ingest all to get ids. Fire in parallel — this is just DB inserts.
  const ingested = await Promise.all(
    engagers.map(async (engager) => {
      try {
        const result = await ingestPostEngager(engager, token);
        sendProgress({ id: result.id, name: engager.name, status: "pending", profileUrl: engager.profileUrl });
        return { id: result.id, engager };
      } catch (err) {
        console.error("[BLI] ingest failed for", engager.name, err);
        return null;
      }
    })
  );

  const valid = ingested.filter(Boolean);

  // Phase 2: enrich each sequentially to avoid LinkedIn rate limits.
  for (const { id, engager } of valid) {
    sendProgress({ id, name: engager.name, status: "enriching", profileUrl: engager.profileUrl });
    try {
      const profileData = await scrapeProfileInBackground(engager.profileUrl);
      const enrichPayload = profileData ? {
        headline: profileData.headline ?? null,
        role: profileData.role ?? null,
        about: profileData.about ?? null,
        recentActivity: profileData.recentActivity ?? null,
      } : {};
      const enrichResult = await enrichPostEngager(id, enrichPayload, token);
      sendProgress({
        id,
        name: engager.name,
        status: "done",
        profileUrl: engager.profileUrl,
        enriched: {
          headline: profileData?.headline ?? null,
          role: profileData?.role ?? null,
          fitVerdict: enrichResult?.fitVerdict ?? null,
          fitReason: enrichResult?.fitReason ?? null,
        },
      });
    } catch (err) {
      console.error("[BLI] enrich failed for", engager.name, err);
      sendProgress({ id, name: engager.name, status: "done", profileUrl: engager.profileUrl });
    }
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "DRAFT_REQUEST") {
    captureThenPoll(msg.data)
      .then((draft) => sendResponse({ ok: true, draft }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true; // keep channel open for async response
  }

  if (msg.type === "CHECK_CONTACTED") {
    checkAlreadyContacted(msg.profileUrl)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch(() => sendResponse({ ok: true, contacted: false }));
    return true;
  }

  if (msg.type === "MARK_SENT") {
    markSent(msg.profileUrl)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "GET_EXISTING_DRAFT") {
    getExistingDraft(msg.profileUrl)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse(null));
    return true;
  }

  if (msg.type === "GET_DAILY_STATS") {
    getDailyStats()
      .then((result) => sendResponse(result))
      .catch(() => sendResponse(null));
    return true;
  }

  if (msg.type === "RESOLVE_CONNECT_BUTTON") {
    resolveConnectButton(msg.profileName, msg.candidates)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "SUBMIT_FEEDBACK") {
    submitFeedback(msg)
      .then((result) => sendResponse(result ?? { ok: false }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === "LIST_CANVASES") {
    listCanvases(msg.apiToken)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse({ canvases: [] }));
    return true;
  }

  if (msg.type === "CHECK_HUBSPOT") {
    checkHubspot(msg.profileUrl, msg.name, msg.company)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch(() => sendResponse({ ok: true, found: false }));
    return true;
  }

  if (msg.type === "GET_POST_ENGAGER") {
    chrome.storage.local.get(["apiToken"], (r) => {
      getPostEngager(msg.id, r.apiToken || "")
        .then((result) => sendResponse(result ?? { status: "not_found" }))
        .catch(() => sendResponse({ status: "not_found" }));
    });
    return true;
  }

  if (msg.type === "IMPORT_SALES_NAV_LIST") {
    importSalesNavList(msg)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "GET_CONTACT") {
    getContact(msg)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "LIST_LEAD_LISTS") {
    listLeadLists()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message, lists: [] }));
    return true;
  }

  if (msg.type === "CHECK_LEADS_IN_LISTS") {
    checkLeadsInLists(msg.salesNavLeadUrls || [])
      .then((result) => sendResponse({ ok: true, ...result }))
      // `ok: false` matters: the panel must not clear a local exclusion on a
      // failed check, only on a successful one that came back clean.
      .catch((err) => sendResponse({ ok: false, error: err.message, inLists: {} }));
    return true;
  }

  if (msg.type === "GET_LEAD_LIST_ITEMS") {
    getLeadListItems(msg.listId)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message, list: null, items: [] }));
    return true;
  }

  if (msg.type === "SUMMARIZE_LEAD_LIST") {
    summarizeLeadList(msg.listId)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message, summary: null }));
    return true;
  }

  if (msg.type === "GENERATE_SALES_NAV_SEARCH") {
    generateSalesNavSearch(msg.prompt)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "LIST_ICP_PERSONAS") {
    listIcpPersonas()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message, personas: [] }));
    return true;
  }

  if (msg.type === "ADD_PERSONA_DOCUMENTS") {
    addPersonaDocuments(msg.personaId, msg.documents)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "DELETE_PERSONA_DOCUMENT") {
    deletePersonaDocument(msg.id)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "CHECK_SALES_NAV_LEADS_CAPTURED") {
    checkSalesNavLeadsCaptured(msg.salesNavLeadUrls)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse({ capturedUrls: [] }));
    return true;
  }
});

// Port-based channel for post-engager loading.
// An open port keeps the service worker alive and guarantees message
// delivery — more reliable than sendMessage for side-panel↔SW communication.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "bli-engager") return;
  console.log("[BLI BG] port connected");

  port.onMessage.addListener(async (msg) => {
    if (msg.type !== "LOAD_POST_ENGAGERS") return;
    console.log("[BLI BG] LOAD_POST_ENGAGERS received", msg.engagers?.length, "engagers");

    const writeProgress = (progress) => {
      console.log("[BLI BG] progress", progress.status, progress.name);
      try { port.postMessage({ type: "POST_ENGAGER_PROGRESS", progress }); } catch { /* port closed */ }
    };

    try {
      await loadPostEngagers(msg.engagers, writeProgress);
      console.log("[BLI BG] loadPostEngagers complete");
      try { port.postMessage({ type: "LOAD_COMPLETE", ok: true }); } catch {}
    } catch (err) {
      console.error("[BLI BG] loadPostEngagers error", err);
      try { port.postMessage({ type: "LOAD_COMPLETE", ok: false, error: err.message }); } catch {}
    }
  });
});

// Open side panel in Chrome; open panel in a new tab in Arc and other
// browsers that don't implement the sidePanel API.
chrome.action.onClicked.addListener((tab) => {
  if (chrome.sidePanel) {
    chrome.sidePanel.open({ tabId: tab.id });
  } else {
    chrome.tabs.create({ url: chrome.runtime.getURL("panel.html") });
  }
});
